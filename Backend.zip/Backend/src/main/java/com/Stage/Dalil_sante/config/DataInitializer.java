package com.Stage.Dalil_sante.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.Stage.Dalil_sante.entity.Utilisateur;
import com.Stage.Dalil_sante.enums.Role;
import com.Stage.Dalil_sante.repository.UtilisateurRepository;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UtilisateurRepository utilisateurRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${app.admin.email}")
    private String adminEmail;

    @Value("${app.admin.password}")
    private String adminPassword;

    @Value("${app.admin.telephone}")
    private String adminTelephone;

    public DataInitializer(
            UtilisateurRepository utilisateurRepository,
            PasswordEncoder passwordEncoder
    ) {
        this.utilisateurRepository = utilisateurRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {

        if (utilisateurRepository.existsByRole(Role.ADMIN)) {
            return;
        }

        Utilisateur admin = new Utilisateur(
                "Super",
                "Admin",
                adminEmail,
                passwordEncoder.encode(adminPassword),
                adminTelephone,
                true,
                Role.ADMIN
        );

        utilisateurRepository.save(admin);

        System.out.println("======================================");
        System.out.println("Super Admin created successfully");
        System.out.println("Email    : " + adminEmail);
        System.out.println("Password : (definie via ADMIN_DEFAULT_PASSWORD, valeur par defaut si non surchargee)");
        System.out.println("A changer immediatement apres la premiere connexion.");
        System.out.println("======================================");
    }
}