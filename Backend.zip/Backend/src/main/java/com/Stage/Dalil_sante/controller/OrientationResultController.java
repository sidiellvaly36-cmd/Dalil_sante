package com.Stage.Dalil_sante.controller;

import com.Stage.Dalil_sante.dto.OrientationResultRequest;
import com.Stage.Dalil_sante.dto.OrientationResultResponse;
import com.Stage.Dalil_sante.entity.OrientationResult;
import com.Stage.Dalil_sante.service.OrientationResultService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orientation/results")
public class OrientationResultController {

    private final OrientationResultService orientationResultService;

    public OrientationResultController(
            OrientationResultService orientationResultService
    ) {
        this.orientationResultService =
                orientationResultService;
    }

    // Ajouter un résultat
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<OrientationResultResponse> createResult(
            @RequestBody OrientationResultRequest request
    ) {

        OrientationResult orientationResult = new OrientationResult(
                request.getTitle(),
                request.getDescription(),
                request.getUrgencyLevel(),
                request.getRecommendedSpecialty(),
                request.getRecommendedEstablishmentType(),
                request.getActive()
        );

        OrientationResult createdResult =
                orientationResultService.createResult(
                        orientationResult
                );

        return ResponseEntity.ok(toResponse(createdResult));
    }

    // Récupérer tous les résultats
    @PreAuthorize("hasAnyRole('ADMIN', 'UTILISATEUR')")
    @GetMapping
    public ResponseEntity<List<OrientationResultResponse>>
    getAllResults() {

        List<OrientationResultResponse> results =
                orientationResultService.getAllResults()
                        .stream()
                        .map(OrientationResultController::toResponse)
                        .toList();

        return ResponseEntity.ok(results);
    }

    // Récupérer uniquement les résultats actifs
    @PreAuthorize("hasAnyRole('ADMIN', 'UTILISATEUR')")
    @GetMapping("/active")
    public ResponseEntity<List<OrientationResultResponse>>
    getActiveResults() {

        List<OrientationResultResponse> results =
                orientationResultService.getActiveResults()
                        .stream()
                        .map(OrientationResultController::toResponse)
                        .toList();

        return ResponseEntity.ok(results);
    }

    // Récupérer un résultat par ID
    @PreAuthorize("hasAnyRole('ADMIN', 'UTILISATEUR')")
    @GetMapping("/{id}")
    public ResponseEntity<OrientationResultResponse> getResultById(
            @PathVariable Long id
    ) {

        return orientationResultService
                .getResultById(id)
                .map(OrientationResultController::toResponse)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Récupérer les résultats par niveau d'urgence
    @PreAuthorize("hasAnyRole('ADMIN', 'UTILISATEUR')")
    @GetMapping("/urgency/{urgencyLevel}")
    public ResponseEntity<List<OrientationResultResponse>>
    getResultsByUrgencyLevel(
            @PathVariable String urgencyLevel
    ) {

        List<OrientationResultResponse> results =
                orientationResultService
                        .getResultsByUrgencyLevel(urgencyLevel)
                        .stream()
                        .map(OrientationResultController::toResponse)
                        .toList();

        return ResponseEntity.ok(results);
    }

    // Modifier un résultat
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<OrientationResultResponse> updateResult(
            @PathVariable Long id,
            @RequestBody OrientationResultRequest request
    ) {

        OrientationResult orientationResult = new OrientationResult(
                request.getTitle(),
                request.getDescription(),
                request.getUrgencyLevel(),
                request.getRecommendedSpecialty(),
                request.getRecommendedEstablishmentType(),
                request.getActive()
        );

        OrientationResult updatedResult =
                orientationResultService.updateResult(
                        id,
                        orientationResult
                );

        return ResponseEntity.ok(toResponse(updatedResult));
    }

    // Supprimer un résultat
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteResult(
            @PathVariable Long id
    ) {

        orientationResultService.deleteResult(id);

        return ResponseEntity.noContent().build();
    }

    private static OrientationResultResponse toResponse(
            OrientationResult orientationResult
    ) {

        return new OrientationResultResponse(
                orientationResult.getId(),
                orientationResult.getTitle(),
                orientationResult.getDescription(),
                orientationResult.getUrgencyLevel(),
                orientationResult.getRecommendedSpecialty(),
                orientationResult.getRecommendedEstablishmentType(),
                orientationResult.getActive()
        );
    }
}