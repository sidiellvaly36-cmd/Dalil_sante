package com.Stage.Dalil_sante.dto;

public class TypeEtablissementResponse {

    private Long id;

    private String nom;

    private String description;

    private Boolean actif;

    public TypeEtablissementResponse() {
    }

    public TypeEtablissementResponse(
            Long id,
            String nom,
            String description,
            Boolean actif
    ) {
        this.id = id;
        this.nom = nom;
        this.description = description;
        this.actif = actif;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getActif() {
        return actif;
    }

    public void setActif(Boolean actif) {
        this.actif = actif;
    }
}