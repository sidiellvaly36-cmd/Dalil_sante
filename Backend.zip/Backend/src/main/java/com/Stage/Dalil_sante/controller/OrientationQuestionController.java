package com.Stage.Dalil_sante.controller;

import com.Stage.Dalil_sante.dto.OrientationQuestionRequest;
import com.Stage.Dalil_sante.dto.OrientationQuestionResponse;
import com.Stage.Dalil_sante.entity.OrientationQuestion;
import com.Stage.Dalil_sante.service.OrientationQuestionService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orientation/questions")
public class OrientationQuestionController {

    private final OrientationQuestionService orientationQuestionService;

    public OrientationQuestionController(
            OrientationQuestionService orientationQuestionService
    ) {
        this.orientationQuestionService = orientationQuestionService;
    }

    // Ajouter une nouvelle question
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<OrientationQuestionResponse> createQuestion(
            @RequestBody OrientationQuestionRequest request
    ) {
        OrientationQuestion orientationQuestion = new OrientationQuestion(
                request.getQuestionText(),
                request.getQuestionOrder(),
                request.getActive()
        );

        OrientationQuestion createdQuestion =
                orientationQuestionService.createQuestion(orientationQuestion);

        return ResponseEntity.ok(toResponse(createdQuestion));
    }

    // Récupérer toutes les questions
    @PreAuthorize("hasAnyRole('ADMIN', 'UTILISATEUR')")
    @GetMapping
    public ResponseEntity<List<OrientationQuestionResponse>> getAllQuestions() {

        List<OrientationQuestionResponse> questions =
                orientationQuestionService.getAllQuestions()
                        .stream()
                        .map(OrientationQuestionController::toResponse)
                        .toList();

        return ResponseEntity.ok(questions);
    }

    // Récupérer uniquement les questions actives
    @PreAuthorize("hasAnyRole('ADMIN', 'UTILISATEUR')")
    @GetMapping("/active")
    public ResponseEntity<List<OrientationQuestionResponse>> getActiveQuestions() {

        List<OrientationQuestionResponse> questions =
                orientationQuestionService.getActiveQuestions()
                        .stream()
                        .map(OrientationQuestionController::toResponse)
                        .toList();

        return ResponseEntity.ok(questions);
    }

    // Récupérer une question par son ID
    @PreAuthorize("hasAnyRole('ADMIN', 'UTILISATEUR')")
    @GetMapping("/{id}")
    public ResponseEntity<OrientationQuestionResponse> getQuestionById(
            @PathVariable Long id
    ) {
        return orientationQuestionService
                .getQuestionById(id)
                .map(OrientationQuestionController::toResponse)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Modifier une question
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<OrientationQuestionResponse> updateQuestion(
            @PathVariable Long id,
            @RequestBody OrientationQuestionRequest request
    ) {
        OrientationQuestion orientationQuestion = new OrientationQuestion(
                request.getQuestionText(),
                request.getQuestionOrder(),
                request.getActive()
        );

        OrientationQuestion updatedQuestion =
                orientationQuestionService.updateQuestion(
                        id,
                        orientationQuestion
                );

        return ResponseEntity.ok(toResponse(updatedQuestion));
    }

    // Supprimer une question
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteQuestion(
            @PathVariable Long id
    ) {
        orientationQuestionService.deleteQuestion(id);

        return ResponseEntity.noContent().build();
    }

    private static OrientationQuestionResponse toResponse(
            OrientationQuestion orientationQuestion
    ) {

        return new OrientationQuestionResponse(
                orientationQuestion.getId(),
                orientationQuestion.getQuestionText(),
                orientationQuestion.getQuestionOrder(),
                orientationQuestion.getActive()
        );
    }
}